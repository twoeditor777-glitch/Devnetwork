// Frontend settings. Safe to commit: nothing secret belongs in this file.
window.DN_CONFIG = {
  // Leave empty when the Worker serves this site (same origin). Only set a full URL
  // if you host the API on a different domain (then cookies need extra CORS work).
  API_URL: "",
  // Tip: download the logo and save it as public/img/logo.png, then set LOGO_URL to "/img/logo.png"
  // so the site doesn't depend on ImgBB staying online.
  LOGO_URL: "https://i.ibb.co/x08PLvM/file-00000000e16082089a2c2ba7f7a9d31c.png",
  DISCORD_URL: "https://discord.gg/ehU3xNU393",
  // Core team shown on the Home and Developers pages. Edit freely.
  TEAM: [
    { name: "minitharki", roles: ["Founder", "Web Developer", "Discord Developer"], founder: true },
    { name: "saksham", roles: ["Web Developer", "Discord Developer"] },
    { name: "pixel", roles: ["Minecraft Developer", "Discord Developer"] },
    { name: "RealSenseiXD", roles: ["Minecraft Developer", "Discord Developer"] }
  ],
  NAME: "DEVNETWORK",
  TAGLINE: "Connect • Create • Collaborate"
};
