(function () {
  "use strict";

  var CFG = window.DN_CONFIG || {};
  var API = (CFG.API_URL || "").replace(/\/$/, "");
  var LOGO = CFG.LOGO_URL || "";
  var NAME = CFG.NAME || "DEVNETWORK";
  var state = { user: null, ready: false };
  var $view = document.getElementById("view");
  var $header = document.getElementById("header");
  var $footer = document.getElementById("footer");

  /* ---------- helpers ---------- */
  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function safeUrl(u) {
    u = String(u || "").trim();
    return /^https?:\/\//i.test(u) ? u : "";
  }
  function split(s) {
    return String(s || "").split(",").map(function (x) { return x.trim(); }).filter(Boolean);
  }
  function tags(s) {
    var t = split(s);
    return t.length ? '<div class="tags">' + t.map(function (x) { return '<span class="tag">' + esc(x) + "</span>"; }).join("") + "</div>" : "";
  }
  function date(ms) { return ms ? new Date(ms).toLocaleDateString() : ""; }
  function discordLink(cls, label) {
    var u = safeUrl(CFG.DISCORD_URL);
    return u ? '<a class="' + cls + '" target="_blank" rel="noopener noreferrer" href="' + esc(u) + '">' + label + "</a>" : "";
  }
  function teamSection(title) {
    var team = CFG.TEAM || [];
    if (!team.length) return "";
    return '<h2 style="font-size:1.4rem">' + esc(title) + '</h2><div class="grid grid-4 mt2">' + team.map(function (m) {
      return '<div class="glass card"><div class="avatar">' + esc(m.name.charAt(0).toUpperCase()) + "</div>" +
        '<h3 class="mt2" style="font-size:1.15rem">' + esc(m.name) + "</h3>" +
        '<div class="tags">' + m.roles.map(function (r) {
          return '<span class="tag' + (r === "Founder" ? " founder" : "") + '">' + esc(r) + "</span>";
        }).join("") + "</div></div>";
    }).join("") + "</div>";
  }
  function isAdmin(u) { return !!u && (u.role === "Admin" || u.role === "Super Admin"); }

  async function api(path, opts) {
    opts = opts || {};
    var init = { method: opts.method || "GET", credentials: "include", headers: {} };
    if (opts.body !== undefined) {
      init.headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(opts.body);
    }
    var res = await fetch(API + path, init);
    var data = {};
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error(data.error || "Request failed (" + res.status + ")");
    return data;
  }

  function setMsg(form, text, ok) {
    var el = form.querySelector(".msg");
    if (el) { el.textContent = text; el.className = "msg " + (ok ? "ok" : "err"); }
  }

  /* ---------- layout ---------- */
  function renderChrome() {
    var path = currentPath();
    function nl(href, label) {
      var on = path === href || (href !== "/" && path.indexOf(href) === 0);
      return '<a href="#' + href + '"' + (on ? ' class="active"' : "") + ">" + label + "</a>";
    }
    var right = !state.ready ? "" : state.user
      ? (isAdmin(state.user) ? '<a class="btn btn-secondary btn-sm" href="#/admin">Admin</a>' : "") +
        '<a class="btn btn-secondary btn-sm" href="#/profile">Profile</a>' +
        '<button class="btn btn-primary btn-sm" data-action="logout">Logout</button>'
      : '<a class="btn btn-secondary btn-sm" href="#/login">Login</a><a class="btn btn-primary btn-sm" href="#/register">Join</a>';
    $header.innerHTML =
      '<div class="wrap"><a class="brand" href="#/"><img src="' + esc(LOGO) + '" alt="' + esc(NAME) + ' logo"><span>' + esc(NAME) + "</span></a>" +
      '<nav class="nav">' + nl("/developers", "Developers") + nl("/projects", "Projects") + nl("/about", "About") + discordLink("", "Discord") + "</nav>" +
      '<div class="actions">' + right + "</div></div>";
    $footer.innerHTML = '<img src="' + esc(LOGO) + '" alt="">' + esc(NAME) + " · " + esc(CFG.TAGLINE || "") + (safeUrl(CFG.DISCORD_URL) ? ' · ' + discordLink("link", "Join our Discord") : "");
  }

  /* ---------- pages ---------- */
  function pageHome() {
    var cards = [
      ["01", "Connect", "Find people by skills, technologies and interests."],
      ["02", "Create", "Build a profile and showcase the work you are proud of."],
      ["03", "Collaborate", "Turn great connections into real projects."]
    ].map(function (c) {
      return '<div class="glass card"><span class="eyebrow">' + c[0] + '</span><h3 class="mt1" style="font-size:1.25rem">' + c[1] + '</h3><p class="muted small lh mt1">' + c[2] + "</p></div>";
    }).join("");
    return '<section class="gridbg"><div class="hero wrap">' +
      '<img class="hero-logo" src="' + esc(LOGO) + '" alt="' + esc(NAME) + '">' +
      '<div class="pill">THE DEVELOPER NETWORK</div>' +
      '<h1>Build your <span class="gradient-text">developer network.</span></h1>' +
      '<p class="lead">Connect with developers, showcase real projects, discover collaborators and grow your presence in one focused community.</p>' +
      '<div class="cta"><a class="btn btn-primary" href="#/register">Create your profile →</a><a class="btn btn-secondary" href="#/developers">Explore developers</a>' + discordLink("btn btn-secondary", "Join our Discord ↗") + '</div>' +
      '</div></section><section class="wrap page"><div class="grid grid-3">' + cards + '</div><div class="mt4">' + teamSection("Meet the team") + "</div></section>";
  }

  async function pageDevelopers() {
    $view.innerHTML = '<main class="wrap page"><h1 class="title">Developers</h1><p class="sub">Meet the team and the community.</p>' +
      '<input class="input mt4" style="max-width:520px" id="dev-search" placeholder="Search developers…" autocomplete="off">' +
      '<div id="team-box"></div><h2 class="mt4" style="font-size:1.4rem">Community developers</h2>' +
      '<div class="grid grid-3 mt2" id="dev-list"><div class="muted">Loading…</div></div></main>';
    var team = [], list = [];
    try {
      var res = await Promise.all([api("/api/team"), api("/api/developers")]);
      team = res[0].team; list = res[1].developers;
    } catch (e) { document.getElementById("dev-list").innerHTML = '<div class="empty" style="grid-column:1/-1">' + esc(e.message) + "</div>"; return; }
    function hit(o, q) { return [o.full_name, o.name, o.username, o.title, o.roles, o.location, o.skills, o.technologies, o.bio].join(" ").toLowerCase().indexOf(q) !== -1; }
    function draw(q) {
      q = (q || "").toLowerCase();
      var t = team.filter(function (x) { return hit(x, q); });
      document.getElementById("team-box").innerHTML = t.length ? '<h2 class="mt4" style="font-size:1.4rem">Core team</h2><div class="grid grid-3 mt2">' + t.map(function (m) {
        var gh = safeUrl(m.github);
        return '<div class="glass card"><div class="row" style="gap:.9rem"><div class="avatar">' + esc((m.name || "?").charAt(0).toUpperCase()) + "</div><div>" +
          '<h3 style="font-size:1.15rem">' + esc(m.name) + '</h3><p class="small" style="color:var(--indigo-soft)">@' + esc(m.username) + "</p></div></div>" +
          (m.title ? '<span class="badge ' + (/founder/i.test(m.title) ? "Pending" : "Approved") + ' mt2" style="display:inline-block">' + esc(m.title) + "</span>" : "") +
          tags(m.roles) + (m.bio ? '<p class="muted small lh mt2">' + esc(m.bio) + "</p>" : "") +
          (m.discord ? '<p class="small muted mt2">Discord: ' + esc(m.discord) + "</p>" : "") +
          (gh ? '<a class="link" style="display:inline-block;margin-top:.6rem" target="_blank" rel="noopener noreferrer" href="' + esc(gh) + '">GitHub ↗</a>' : "") + "</div>";
      }).join("") + "</div>" : "";
      var shown = list.filter(function (x) { return hit(x, q); });
      document.getElementById("dev-list").innerHTML = shown.length ? shown.map(function (d) {
        return '<div class="glass card"><div class="avatar">' + esc((d.full_name || "?").charAt(0).toUpperCase()) + "</div>" +
          '<h2 class="mt2" style="font-size:1.25rem">' + esc(d.full_name) + '</h2><p class="small" style="color:var(--indigo-soft)">@' + esc(d.username) + (d.location ? " · " + esc(d.location) : "") + "</p>" +
          '<p class="muted small lh mt2">' + esc((d.bio || "").slice(0, 140)) + "</p>" + tags(d.skills) +
          '<a class="link" style="display:inline-block;margin-top:1.1rem" href="#/developer/' + encodeURIComponent(d.username) + '">View profile →</a></div>';
      }).join("") : '<div class="empty" style="grid-column:1/-1">' + (list.length ? "No developers match your search." : 'No community developers yet. <a class="link" href="#/apply">Apply now</a>.') + "</div>";
    }
    draw("");
    document.getElementById("dev-search").addEventListener("input", function (e) { draw(e.target.value); });
  }

  async function pageDeveloper(username) {
    $view.innerHTML = '<main class="wrap page medium"><div class="muted">Loading…</div></main>';
    try {
      var d = (await api("/api/developers/" + encodeURIComponent(username))).developer;
      var links = [["GitHub", d.github], ["Portfolio", d.portfolio]].filter(function (l) { return safeUrl(l[1]); })
        .map(function (l) { return '<a class="btn btn-secondary btn-sm" target="_blank" rel="noopener noreferrer" href="' + esc(safeUrl(l[1])) + '">' + l[0] + " ↗</a>"; }).join("");
      $view.innerHTML = '<main class="wrap page medium"><div class="glass card-lg"><div class="row" style="gap:1.2rem"><div class="avatar lg">' + esc(d.full_name.charAt(0).toUpperCase()) + "</div><div>" +
        '<h1 class="title" style="font-size:2rem">' + esc(d.full_name) + '</h1><p class="muted">@' + esc(d.username) + (d.location ? " · " + esc(d.location) : "") + "</p></div></div>" +
        (d.bio ? '<p class="lh mt3" style="color:var(--soft)">' + esc(d.bio) + "</p>" : "") +
        '<p class="eyebrow mt3">Skills</p>' + (tags(d.skills) || '<p class="muted small mt1">—</p>') +
        '<p class="eyebrow mt3">Technologies</p>' + (tags(d.technologies) || '<p class="muted small mt1">—</p>') +
        (d.experience ? '<p class="eyebrow mt3">Experience</p><p class="muted mt1">' + esc(d.experience) + "</p>" : "") +
        (links ? '<div class="row mt3">' + links + "</div>" : "") + "</div></main>";
    } catch (e) {
      $view.innerHTML = '<main class="wrap page medium"><div class="empty">' + esc(e.message) + ' <a class="link" href="#/developers">Back to developers</a></div></main>';
    }
  }

  async function pageProjects() {
    $view.innerHTML = '<main class="wrap page"><div class="row between"><div><h1 class="title">Projects</h1><p class="sub">A home for work worth showing.</p></div>' +
      (state.user && state.user.role !== "User" ? '<button class="btn btn-primary" data-action="toggle-project-form">+ Add project</button>' : "") + "</div>" +
      '<div id="project-form-slot"></div><div class="grid grid-3 mt4" id="project-list"><div class="muted">Loading…</div></div></main>';
    try {
      var list = (await api("/api/projects")).projects;
      document.getElementById("project-list").innerHTML = list.length ? list.map(function (p) {
        var links = [["Code", p.github_url], ["Live", p.live_url]].filter(function (l) { return safeUrl(l[1]); })
          .map(function (l) { return '<a class="link" target="_blank" rel="noopener noreferrer" href="' + esc(safeUrl(l[1])) + '">' + l[0] + " ↗</a>"; }).join(" &nbsp; ");
        return '<div class="glass card"><div class="project-cover"></div><h2 class="mt2" style="font-size:1.25rem">' + esc(p.title) + "</h2>" +
          '<p class="small" style="color:var(--indigo-soft)">by @' + esc(p.owner_username) + '</p><p class="muted small lh mt1">' + esc(p.description || "") + "</p>" + tags(p.technologies) +
          (links ? '<div class="mt2">' + links + "</div>" : "") + "</div>";
      }).join("") : '<div class="empty" style="grid-column:1/-1">No projects yet.</div>';
    } catch (e) {
      document.getElementById("project-list").innerHTML = '<div class="empty" style="grid-column:1/-1">' + esc(e.message) + "</div>";
    }
  }

  function pageAbout() {
    var items = ["Profiles", "Projects", "Collaboration"].map(function (x) {
      return '<div class="glass card"><b>' + x + '</b><p class="muted small mt1">Built as a scalable Cloudflare application.</p></div>';
    }).join("");
    return '<main class="wrap page medium"><div class="glass card-lg"><h1 class="title">About ' + esc(NAME) + "</h1>" +
      '<p class="lh mt3" style="font-size:1.1rem;color:var(--soft)">A focused place for developers to connect, create and collaborate. The platform is designed around people and their work rather than noise.</p>' +
      '<div class="grid grid-3 mt4">' + items + "</div></div></main>";
  }

  function pageAuth(mode) {
    var login = mode === "login";
    return '<main class="wrap page narrow"><div class="glass glow card-lg"><h1 class="title" style="font-size:1.9rem">' + (login ? "Welcome back" : "Join " + esc(NAME)) + "</h1>" +
      '<p class="muted small mt1">' + (login ? "Sign in to continue." : "Create your developer account.") + "</p>" +
      '<form class="form" data-form="' + mode + '" novalidate>' +
      (login ? "" : '<input class="input" name="name" placeholder="Full name" required autocomplete="name"><input class="input" name="username" placeholder="Username (letters, numbers, _)" required autocomplete="username">') +
      '<input class="input" name="email" ' + (login ? 'placeholder="Email or username"' : 'type="email" placeholder="Email"') + ' required autocomplete="' + (login ? "username" : "email") + '">' +
      '<input class="input" type="password" name="password" placeholder="' + (login ? "Password" : "Password (8+ characters)") + '" required autocomplete="' + (login ? "current-password" : "new-password") + '">' +
      '<p class="msg"></p><button class="btn btn-primary btn-block">' + (login ? "Login" : "Create account") + "</button></form>" +
      '<p class="small muted mt3" style="text-align:center">' + (login ? 'New here? <a class="link" href="#/register">Create an account</a>' : 'Already registered? <a class="link" href="#/login">Login</a>') + "</p></div></main>";
  }

  async function pageProfile() {
    var u = state.user;
    if (!u) return redirect("/login");
    $view.innerHTML = '<main class="wrap page medium"><div class="glass card-lg"><p class="eyebrow">Your account</p><h1 class="title mt1">' + esc(u.name || u.username) + "</h1>" +
      '<p class="muted mt1">@' + esc(u.username) + " · " + esc(u.email) + ' · <span class="badge Approved">' + esc(u.role) + "</span></p>" +
      '<div class="grid grid-2 mt4"><a class="glass card" href="#/apply"><b>' + (u.role === "User" ? "Apply as a developer →" : "Your developer application →") + '</b><p class="muted small mt1">Submit or check your profile for approval.</p></a>' +
      '<a class="glass card" href="#/projects"><b>Projects →</b><p class="muted small mt1">Explore showcased work.</p></a></div></div>' +
      '<h2 class="mt4" style="font-size:1.3rem">Notifications</h2><div class="grid mt2" id="notes"><div class="muted">Loading…</div></div></main>';
    try {
      var notes = (await api("/api/notifications")).notifications;
      document.getElementById("notes").innerHTML = notes.length ? notes.map(function (n) {
        return '<div class="note ' + (n.read_at ? "" : "unread") + '"><b>' + esc(n.title) + "</b>" + esc(n.message || "") + '<div class="muted small mt1">' + date(n.created_at) + "</div></div>";
      }).join("") : '<div class="empty">No notifications yet.</div>';
      if (notes.some(function (n) { return !n.read_at; })) api("/api/notifications/read", { method: "POST" }).catch(function () {});
    } catch (e) { document.getElementById("notes").innerHTML = '<div class="empty">' + esc(e.message) + "</div>"; }
  }

  var APPLY_FIELDS = [
    ["full_name", "Full name", true], ["username", "Public username", true], ["location", "Location"], ["experience", "Experience (e.g. 3 years)"],
    ["github", "GitHub URL"], ["portfolio", "Portfolio URL"], ["discord", "Discord"], ["skills", "Skills (comma separated)", true],
    ["technologies", "Technologies (comma separated)", true], ["social_links", "Other social links"], ["project_links", "Project links"]
  ];
  async function pageApply() {
    var u = state.user;
    if (!u) return redirect("/login");
    $view.innerHTML = '<main class="wrap page medium"><div class="muted">Loading…</div></main>';
    var mine = [];
    try { mine = (await api("/api/applications/mine")).applications; } catch (e) {}
    var last = mine[0];
    var status = "";
    if (last) {
      status = '<div class="note mt3"><b>Latest application: <span class="badge ' + esc(last.status) + '">' + esc(last.status) + "</span></b>Submitted " + date(last.created_at) +
        (last.status === "Rejected" && last.rejection_reason ? "<br>Reason: " + esc(last.rejection_reason) : "") + "</div>";
    }
    var blocked = u.role !== "User" ? "You are already approved as " + u.role + "." : (last && last.status === "Pending" ? "Your application is pending review." : "");
    var form = blocked ? '<div class="empty mt3">' + esc(blocked) + "</div>" :
      '<form class="form cols" data-form="apply">' + APPLY_FIELDS.map(function (f) {
        return '<label class="field">' + esc(f[1]) + (f[2] ? " *" : "") + '<input class="input" name="' + f[0] + '"' + (f[2] ? " required" : "") + (f[0] === "username" ? ' value="' + esc(u.username) + '"' : "") + "></label>";
      }).join("") +
      '<label class="field span2">Bio<textarea class="input" name="bio"></textarea></label>' +
      '<label class="field span2">Why do you want to join? *<textarea class="input" name="why_join" required></textarea></label>' +
      '<label class="field span2">What can you contribute?<textarea class="input" name="contribution"></textarea></label>' +
      '<p class="msg span2"></p><button class="btn btn-primary span2">Submit application</button></form>';
    $view.innerHTML = '<main class="wrap page medium"><div class="glass card-lg"><h1 class="title" style="font-size:1.9rem">Developer application</h1><p class="muted mt1">Tell us what you build and how you can contribute.</p>' + status + form + "</div></main>";
  }

  async function pageAdmin() {
    if (!isAdmin(state.user)) return redirect(state.user ? "/" : "/login");
    var filter = pageAdmin.filter || "Pending";
    $view.innerHTML = '<main class="wrap page medium"><h1 class="title">Admin panel</h1><p class="sub">Review developer applications.</p>' +
      '<div class="tabs">' + ["Pending", "Approved", "Rejected", "All", "Team"].map(function (t) {
        return '<button class="tab ' + (t === filter ? "on" : "") + '" data-action="admin-filter" data-status="' + t + '">' + t + "</button>";
      }).join("") + '</div><div class="grid mt3" id="apps"><div class="muted">Loading…</div></div></main>';
    if (filter === "Team") return adminTeam();
    try {
      var apps = (await api("/api/admin/applications" + (filter === "All" ? "" : "?status=" + filter))).applications;
      document.getElementById("apps").innerHTML = apps.length ? apps.map(function (a) {
        var rows = [["Username", "@" + a.username], ["Account", a.account_email], ["Location", a.location], ["Experience", a.experience], ["GitHub", a.github], ["Portfolio", a.portfolio],
          ["Skills", a.skills], ["Technologies", a.technologies], ["Bio", a.bio], ["Why join", a.why_join], ["Contribution", a.contribution]]
          .filter(function (r) { return r[1]; }).map(function (r) { return "<dt>" + r[0] + "</dt><dd>" + esc(r[1]) + "</dd>"; }).join("");
        var act = a.status === "Pending"
          ? '<div class="row"><button class="btn btn-ok btn-sm" data-action="approve" data-id="' + esc(a.id) + '">Approve</button>' +
            '<input class="input" style="max-width:280px;padding:.5rem .7rem" placeholder="Rejection reason" data-reason="' + esc(a.id) + '">' +
            '<button class="btn btn-danger btn-sm" data-action="reject" data-id="' + esc(a.id) + '">Reject</button></div>'
          : (a.rejection_reason ? '<p class="small muted">Reason: ' + esc(a.rejection_reason) + "</p>" : "");
        return '<div class="glass app"><div class="row between"><b>' + esc(a.full_name) + '</b><span class="badge ' + esc(a.status) + '">' + esc(a.status) + "</span></div><dl>" + rows + "</dl>" + act + "</div>";
      }).join("") : '<div class="empty">No ' + (filter === "All" ? "" : filter.toLowerCase() + " ") + "applications.</div>";
    } catch (e) { document.getElementById("apps").innerHTML = '<div class="empty">' + esc(e.message) + "</div>"; }
  }

  async function adminTeam() {
    var box = document.getElementById("apps");
    function fld(n, l, v, req) { return '<label class="field">' + l + '<input class="input" name="' + n + '" value="' + esc(v || "") + '"' + (req ? " required" : "") + "></label>"; }
    try {
      var team = (await api("/api/team")).team;
      adminTeam.cache = team;
      box.innerHTML = '<form class="glass card form cols" data-form="team"><input type="hidden" name="id" value="">' +
        fld("name", "Display name *", "", 1) + fld("username", "Username *", "", 1) + fld("title", "Title (e.g. Founder)") + fld("roles", "Roles (comma separated)") +
        fld("github", "GitHub URL") + fld("discord", "Discord") + fld("sort_order", "Order (1 = first)", "100") +
        '<label class="field span2">Bio<textarea class="input" name="bio"></textarea></label><p class="msg span2"></p><button class="btn btn-primary span2">Add team member</button></form>' +
        team.map(function (t) {
          return '<div class="glass app"><div class="row between"><b>' + esc(t.name) + ' <span class="muted small">@' + esc(t.username) + '</span></b><span class="row">' +
            '<button class="btn btn-secondary btn-sm" data-action="team-edit" data-id="' + esc(t.id) + '">Edit</button>' +
            '<button class="btn btn-danger btn-sm" data-action="team-delete" data-id="' + esc(t.id) + '">Delete</button></span></div>' +
            '<p class="small muted">' + esc([t.title, t.roles].filter(Boolean).join(" · ")) + "</p></div>";
        }).join("");
    } catch (e) { box.innerHTML = '<div class="empty">' + esc(e.message) + "</div>"; }
  }

  /* ---------- router ---------- */
  function currentPath() { return (location.hash.slice(1) || "/").split("?")[0]; }
  function redirect(p) { location.hash = "#" + p; }

  async function render() {
    renderChrome();
    var p = currentPath(), m;
    window.scrollTo(0, 0);
    if (p === "/") $view.innerHTML = pageHome();
    else if (p === "/developers") await pageDevelopers();
    else if ((m = p.match(/^\/developer\/(.+)$/))) await pageDeveloper(decodeURIComponent(m[1]));
    else if (p === "/projects") await pageProjects();
    else if (p === "/about") $view.innerHTML = pageAbout();
    else if (p === "/login" || p === "/register") $view.innerHTML = pageAuth(p.slice(1));
    else if (p === "/profile") await pageProfile();
    else if (p === "/apply") await pageApply();
    else if (p === "/admin") await pageAdmin();
    else $view.innerHTML = pageHome();
    document.title = NAME;
  }

  /* ---------- events ---------- */
  document.addEventListener("submit", async function (e) {
    var form = e.target.closest("form[data-form]");
    if (!form) return;
    e.preventDefault();
    var kind = form.getAttribute("data-form");
    var data = Object.fromEntries(new FormData(form));
    var btn = form.querySelector("button");
    if (btn) btn.disabled = true;
    setMsg(form, "", true);
    try {
      if (kind === "login" || kind === "register") {
        var r = await api("/api/auth/" + kind, { method: "POST", body: data });
        state.user = r.user;
        redirect("/profile");
        render();
      } else if (kind === "apply") {
        await api("/api/applications", { method: "POST", body: data });
        await pageApply();
      } else if (kind === "team") {
        var tid = data.id; delete data.id;
        await api("/api/admin/team" + (tid ? "/" + encodeURIComponent(tid) : ""), { method: tid ? "PUT" : "POST", body: data });
        await adminTeam();
      } else if (kind === "project") {
        await api("/api/projects", { method: "POST", body: data });
        await pageProjects();
      }
    } catch (err) {
      setMsg(form, err.message, false);
      if (btn) btn.disabled = false;
    }
  });

  document.addEventListener("click", async function (e) {
    var el = e.target.closest("[data-action]");
    if (!el) return;
    var act = el.getAttribute("data-action");
    try {
      if (act === "logout") {
        await api("/api/auth/logout", { method: "POST" }).catch(function () {});
        state.user = null;
        redirect("/");
        render();
      } else if (act === "admin-filter") {
        pageAdmin.filter = el.getAttribute("data-status");
        await pageAdmin();
      } else if (act === "approve" || act === "reject") {
        var id = el.getAttribute("data-id");
        var body = {};
        if (act === "reject") {
          var input = document.querySelector('[data-reason="' + id + '"]');
          body.reason = input ? input.value.trim() : "";
          if (!body.reason) { alert("Please enter a rejection reason."); return; }
        }
        el.disabled = true;
        await api("/api/admin/applications/" + encodeURIComponent(id) + "/" + act, { method: "POST", body: body });
        await pageAdmin();
      } else if (act === "team-edit") {
        var tf = document.querySelector('form[data-form="team"]');
        var row = (adminTeam.cache || []).filter(function (x) { return x.id === el.getAttribute("data-id"); })[0];
        if (tf && row) {
          ["id", "name", "username", "title", "roles", "bio", "github", "discord", "sort_order"].forEach(function (k) { if (tf.elements[k]) tf.elements[k].value = row[k] == null ? "" : row[k]; });
          tf.querySelector("button").textContent = "Save changes";
          tf.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      } else if (act === "team-delete") {
        if (!confirm("Remove this team member from the site?")) return;
        await api("/api/admin/team/" + encodeURIComponent(el.getAttribute("data-id")), { method: "DELETE" });
        await adminTeam();
      } else if (act === "toggle-project-form") {
        var slot = document.getElementById("project-form-slot");
        slot.innerHTML = slot.innerHTML ? "" :
          '<form class="glass card form cols mt3" data-form="project"><input class="input" name="title" placeholder="Project title *" required>' +
          '<input class="input" name="technologies" placeholder="Technologies (comma separated)"><input class="input" name="github_url" placeholder="GitHub URL"><input class="input" name="live_url" placeholder="Live URL">' +
          '<textarea class="input span2" name="description" placeholder="Description"></textarea><p class="msg span2"></p><button class="btn btn-primary span2">Publish project</button></form>';
      }
    } catch (err) { alert(err.message); if (el) el.disabled = false; }
  });

  window.addEventListener("hashchange", render);

  /* ---------- boot ---------- */
  (async function boot() {
    renderChrome();
    try { state.user = (await api("/api/auth/me")).user; } catch (e) { state.user = null; }
    state.ready = true;
    render();
  })();
})();
