CREATE TABLE IF NOT EXISTS team_members(id TEXT PRIMARY KEY,username TEXT NOT NULL UNIQUE,name TEXT NOT NULL,title TEXT,roles TEXT,bio TEXT,github TEXT,discord TEXT,sort_order INTEGER NOT NULL DEFAULT 100,created_at INTEGER NOT NULL);
INSERT OR IGNORE INTO team_members(id,username,name,title,roles,bio,github,discord,sort_order,created_at) VALUES
('team-minitharki','minitharki','minitharki','Founder','Web Developer, Discord Developer','Founder of DEVNETWORK.','','',1,strftime('%s','now')*1000),
('team-saksham','saksham','saksham','Developer','Web Developer, Discord Developer','','','',2,strftime('%s','now')*1000),
('team-pixel','pixel','pixel','Developer','Minecraft Developer, Discord Developer','','','',3,strftime('%s','now')*1000),
('team-realsenseixd','realsenseixd','RealSenseiXD','Developer','Minecraft Developer, Discord Developer','','','',4,strftime('%s','now')*1000);
