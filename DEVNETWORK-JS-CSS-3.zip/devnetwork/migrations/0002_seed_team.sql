-- Seeds the three DEVNETWORK developers so they show on the Developers page.
-- These are display-only accounts: the password hash below can never match a real password.
-- To claim one later: DELETE FROM users WHERE username='saksham'; (profile is removed too), then register and apply normally.
INSERT OR IGNORE INTO users(id,email,username,name,password_hash,password_salt,role,email_verified,created_at) VALUES
('seed-saksham','saksham@devnetwork.invalid','saksham','Saksham','AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','AAAAAAAAAAAAAAAAAAAAAA','Developer',0,strftime('%s','now')*1000),
('seed-pixel','pixel@devnetwork.invalid','pixel','Pixel','AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','AAAAAAAAAAAAAAAAAAAAAA','Developer',0,strftime('%s','now')*1000),
('seed-realsenseixd','realsenseixd@devnetwork.invalid','realsenseixd','RealSenseiXD','AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA','AAAAAAAAAAAAAAAAAAAAAA','Developer',0,strftime('%s','now')*1000);
INSERT OR IGNORE INTO developer_profiles(id,user_id,full_name,location,bio,skills,technologies,experience,github,portfolio,discord,social_links,approved_at) VALUES
('seedp-saksham','seed-saksham','Saksham','','Web Developer at DEVNETWORK.','Web Development','JavaScript, HTML, CSS','','','','','',strftime('%s','now')*1000+2),
('seedp-pixel','seed-pixel','Pixel','','Minecraft Developer at DEVNETWORK.','Minecraft Development','Minecraft','','','','','',strftime('%s','now')*1000+1),
('seedp-realsenseixd','seed-realsenseixd','RealSenseiXD','','Minecraft Developer at DEVNETWORK.','Minecraft Development','Minecraft','','','','','',strftime('%s','now')*1000);
