# DEVNETWORK

Connect • Create • Collaborate

Plain **JavaScript + CSS** — no React, Vite, Tailwind or build step. One Cloudflare Worker serves both the site (`public/`) and the API (`/api/*`), backed by D1.

## Structure
- `public/` — the website (`index.html`, `css/style.css`, `js/app.js`, `js/config.js`)
- `worker/src/index.js` — API (auth, developer applications, admin review, developers, projects, notifications)
- `migrations/` — D1 SQL
- `wrangler.jsonc` — Worker + static assets + D1 + R2 config

## Logo
The logo is loaded from ImgBB (`public/js/config.js` and `public/index.html`). To stop depending on ImgBB, download it, save it as `public/img/logo.png`, and replace the ImgBB URL with `/img/logo.png` in those two files.

## Local development
1. Node.js 20+, then `npm install`
2. `npx wrangler login`
3. `npx wrangler d1 create devnetwork-db` → paste the returned `database_id` into `wrangler.jsonc`
4. `cp .dev.vars.example .dev.vars` and set `SUPER_ADMIN_EMAIL` to your email
5. `npm run db:local`
6. `npm run dev` → open the printed URL (usually http://localhost:8787)

Register with the email you set in `SUPER_ADMIN_EMAIL`; that account becomes Super Admin and sees the **Admin** button.

## Deploy
1. `npm run db:remote` (applies migrations to the real D1 database)
2. `npx wrangler r2 bucket create devnetwork-uploads`
3. `npx wrangler secret put SUPER_ADMIN_EMAIL` (enter your email)
4. `npm run deploy`

### Deploy from GitHub
Push this repo to GitHub, then in Cloudflare: **Workers & Pages → Create → Import a repository**. Build command: leave empty. Deploy command: `npx wrangler deploy`. Add `SUPER_ADMIN_EMAIL` under Settings → Variables and Secrets.

## How it works
- Passwords: PBKDF2-SHA-256 (100,000 iterations — the Workers maximum), per-user salt.
- Sessions: random token in an HttpOnly cookie; only its SHA-256 hash is stored in D1.
- Roles: User → Developer (after approval) → Admin / Super Admin.
- Applications: Pending → Approved / Rejected. Rejections need a reason and block reapplying for 7 days. Approval makes the profile public and notifies the user.
- All user text is escaped in the browser and links are limited to http(s).

## Team
`migrations/0002_seed_team.sql` lists Saksham (web developer), Pixel and RealSenseiXD (Minecraft developers) on the Developers page. They are display-only accounts. To log in as one, first run `npx wrangler d1 execute devnetwork-db --remote --command "DELETE FROM users WHERE username='saksham'"` (use their username), then register and apply normally.

## Not included yet
Email verification / password reset (needs an email provider), image uploads to R2 (the bucket is bound as `UPLOADS`), and rate limiting (use Cloudflare WAF rules).

## Core team (admin-managed)
The **Core team** section on the Developers page comes from the `team_members` table (seeded by `migrations/0002_team.sql`: minitharki — Founder, saksham, pixel, RealSenseiXD). Log in with the `SUPER_ADMIN_EMAIL` account → **Admin → Team** to add, edit, reorder or remove members. Community developers still join through **Apply** and appear after an admin approves them.
If your database already exists, apply the new migration: `npm run db:remote` (or paste `0002_team.sql` into the D1 console).
