// DEVNETWORK API (Cloudflare Worker + D1). Also serves the static site from ./public.

const enc = new TextEncoder();
const DAY = 86400000;
const SESSION_MS = 14 * DAY;
const REAPPLY_COOLDOWN_MS = 7 * DAY;
const PBKDF2_ITERATIONS = 100000; // Workers rejects anything above 100,000

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers },
  });

/* ---------- crypto ---------- */
function toB64(buf) {
  let s = "";
  new Uint8Array(buf).forEach((b) => (s += String.fromCharCode(b)));
  return btoa(s).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}
function fromB64(s) {
  s = s.replaceAll("-", "+").replaceAll("_", "/");
  while (s.length % 4) s += "=";
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}
async function pbkdf2(password, salt) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  return crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: PBKDF2_ITERATIONS, hash: "SHA-256" }, key, 256);
}
async function newPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return { salt: toB64(salt), hash: toB64(await pbkdf2(password, salt)) };
}
async function checkPassword(password, saltB64, hashB64) {
  const got = new Uint8Array(await pbkdf2(password, fromB64(saltB64)));
  const want = fromB64(hashB64);
  if (got.length !== want.length) return false;
  let diff = 0;
  for (let i = 0; i < got.length; i++) diff |= got[i] ^ want[i];
  return diff === 0;
}
async function sha256Hex(text) {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(text)));
  return [...d].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/* ---------- small helpers ---------- */
const uid = () => crypto.randomUUID();
const str = (v, max = 2000) => (typeof v === "string" ? v.trim().slice(0, max) : "");
function cleanUrl(v) {
  const s = str(v, 500);
  if (!s) return "";
  try {
    const u = new URL(s);
    return u.protocol === "http:" || u.protocol === "https:" ? u.href : "";
  } catch { return ""; }
}
async function body(req) {
  try {
    const b = await req.json();
    if (b && typeof b === "object" && !Array.isArray(b)) return b;
  } catch {}
  throw new HttpError(400, "Invalid request body");
}
const publicUser = (u) => ({ id: u.id, email: u.email, username: u.username, name: u.name, role: u.role });
const isAdmin = (u) => u.role === "Admin" || u.role === "Super Admin";

function cookieHeader(req, token, maxAge) {
  const secure = new URL(req.url).protocol === "https:" ? "; Secure" : "";
  return `dn_session=${token}; Max-Age=${maxAge}; Path=/; HttpOnly; SameSite=Lax${secure}`;
}

/* ---------- sessions / users ---------- */
async function createSession(env, userId) {
  const token = toB64(crypto.getRandomValues(new Uint8Array(32)));
  const now = Date.now();
  await env.DB.prepare("DELETE FROM sessions WHERE expires_at<?").bind(now).run();
  await env.DB.prepare("INSERT INTO sessions(id,user_id,token,expires_at,created_at) VALUES(?,?,?,?,?)")
    .bind(uid(), userId, await sha256Hex(token), now + SESSION_MS, now).run();
  return token;
}
function tokenFrom(req) {
  const m = (req.headers.get("Cookie") || "").match(/(?:^|;\s*)dn_session=([^;]+)/);
  return m ? m[1] : null;
}
async function getUser(req, env) {
  const token = tokenFrom(req);
  if (!token) return null;
  return (await env.DB.prepare("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?")
    .bind(await sha256Hex(token), Date.now()).first()) || null;
}
// The Super Admin is whoever owns the SUPER_ADMIN_EMAIL secret. No passwords live in code.
async function syncSuperAdmin(env, user) {
  const want = (env.SUPER_ADMIN_EMAIL || "").trim().toLowerCase();
  if (want && user.email === want && user.role !== "Super Admin") {
    await env.DB.prepare("UPDATE users SET role='Super Admin' WHERE id=?").bind(user.id).run();
    user.role = "Super Admin";
  }
  return user;
}
async function notify(env, userId, type, title, message) {
  await env.DB.prepare("INSERT INTO notifications(id,user_id,type,title,message,created_at) VALUES(?,?,?,?,?,?)")
    .bind(uid(), userId, type, title, message, Date.now()).run();
}

/* ---------- routes ---------- */
async function route(req, env) {
  const url = new URL(req.url);
  const p = url.pathname.replace(/\/+$/, "") || "/";
  const m = req.method;
  let r;

  if (p === "/api/health") return json({ ok: true, service: "devnetwork" });

  /* --- auth --- */
  if (p === "/api/auth/register" && m === "POST") {
    const b = await body(req);
    const name = str(b.name, 80), email = str(b.email, 200).toLowerCase(), username = str(b.username, 30).toLowerCase();
    const password = typeof b.password === "string" ? b.password : "";
    if (!name || !email || !username || !password) throw new HttpError(400, "Name, username, email and password are required");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new HttpError(400, "Enter a valid email address");
    if (!/^[a-z0-9_]{3,30}$/.test(username)) throw new HttpError(400, "Username must be 3-30 characters: letters, numbers or _");
    if (password.length < 8 || password.length > 200) throw new HttpError(400, "Password must be 8-200 characters");
    if (await env.DB.prepare("SELECT id FROM users WHERE email=? OR username=?").bind(email, username).first())
      throw new HttpError(409, "Email or username already exists");
    const pw = await newPassword(password), id = uid();
    await env.DB.prepare("INSERT INTO users(id,email,username,name,password_hash,password_salt,role,email_verified,created_at) VALUES(?,?,?,?,?,?,?,?,?)")
      .bind(id, email, username, name, pw.hash, pw.salt, "User", 0, Date.now()).run();
    const user = await syncSuperAdmin(env, { id, email, username, name, role: "User" });
    const token = await createSession(env, id);
    return json({ user: publicUser(user) }, 200, { "Set-Cookie": cookieHeader(req, token, SESSION_MS / 1000) });
  }

  if (p === "/api/auth/login" && m === "POST") {
    const b = await body(req);
    const login = str(b.email, 200).toLowerCase();
    const password = typeof b.password === "string" ? b.password : "";
    const u = login ? await env.DB.prepare("SELECT * FROM users WHERE email=? OR username=?").bind(login, login).first() : null;
    if (!u || !(await checkPassword(password, u.password_salt, u.password_hash))) throw new HttpError(401, "Invalid credentials");
    await syncSuperAdmin(env, u);
    const token = await createSession(env, u.id);
    return json({ user: publicUser(u) }, 200, { "Set-Cookie": cookieHeader(req, token, SESSION_MS / 1000) });
  }

  if (p === "/api/auth/me" && m === "GET") {
    const u = await getUser(req, env);
    return json({ user: u ? publicUser(u) : null });
  }

  if (p === "/api/auth/logout" && m === "POST") {
    const t = tokenFrom(req);
    if (t) await env.DB.prepare("DELETE FROM sessions WHERE token=?").bind(await sha256Hex(t)).run();
    return json({ ok: true }, 200, { "Set-Cookie": cookieHeader(req, "", 0) });
  }

  /* --- public data --- */
  if (p === "/api/developers" && m === "GET") {
    const rows = await env.DB.prepare(
      "SELECT u.username,d.full_name,d.location,d.bio,d.skills,d.technologies,d.github,d.portfolio FROM developer_profiles d JOIN users u ON u.id=d.user_id ORDER BY d.approved_at DESC LIMIT 200"
    ).all();
    return json({ developers: rows.results });
  }
  if ((r = p.match(/^\/api\/developers\/([^/]+)$/)) && m === "GET") {
    const row = await env.DB.prepare(
      "SELECT u.username,d.full_name,d.location,d.bio,d.skills,d.technologies,d.experience,d.github,d.portfolio FROM developer_profiles d JOIN users u ON u.id=d.user_id WHERE u.username=?"
    ).bind(decodeURIComponent(r[1]).toLowerCase()).first();
    if (!row) throw new HttpError(404, "Developer not found");
    return json({ developer: row });
  }
  if (p === "/api/projects" && m === "GET") {
    const rows = await env.DB.prepare(
      "SELECT p.id,p.title,p.slug,p.description,p.technologies,p.github_url,p.live_url,u.username AS owner_username FROM projects p JOIN users u ON u.id=p.owner_id WHERE p.status='Published' ORDER BY p.created_at DESC LIMIT 100"
    ).all();
    return json({ projects: rows.results });
  }

  if (p === "/api/team" && m === "GET") {
    const rows = await env.DB.prepare("SELECT id,username,name,title,roles,bio,github,discord,sort_order FROM team_members ORDER BY sort_order,name").all();
    return json({ team: rows.results });
  }

  /* --- everything below needs a session --- */
  const user = await getUser(req, env);
  if (!user) throw new HttpError(401, "Authentication required");

  if (p === "/api/notifications" && m === "GET") {
    const rows = await env.DB.prepare("SELECT id,type,title,message,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50").bind(user.id).all();
    return json({ notifications: rows.results });
  }
  if (p === "/api/notifications/read" && m === "POST") {
    await env.DB.prepare("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL").bind(Date.now(), user.id).run();
    return json({ ok: true });
  }

  if (p === "/api/projects" && m === "POST") {
    if (user.role === "User") throw new HttpError(403, "Only approved developers can add projects");
    const b = await body(req);
    const title = str(b.title, 120);
    if (!title) throw new HttpError(400, "Title is required");
    const slug = (title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "project") + "-" + uid().slice(0, 6);
    await env.DB.prepare("INSERT INTO projects(id,owner_id,title,slug,description,technologies,github_url,live_url,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)")
      .bind(uid(), user.id, title, slug, str(b.description, 2000), str(b.technologies, 300), cleanUrl(b.github_url), cleanUrl(b.live_url), "Published", Date.now()).run();
    return json({ ok: true, slug });
  }

  if (p === "/api/applications/mine" && m === "GET") {
    const rows = await env.DB.prepare("SELECT id,status,rejection_reason,created_at,reviewed_at FROM developer_applications WHERE user_id=? ORDER BY created_at DESC LIMIT 10").bind(user.id).all();
    return json({ applications: rows.results });
  }

  if (p === "/api/applications" && m === "POST") {
    if (user.role !== "User") throw new HttpError(409, `You are already a ${user.role}`);
    const b = await body(req);
    const f = {
      full_name: str(b.full_name, 80), username: str(b.username, 30).toLowerCase(), location: str(b.location, 100), bio: str(b.bio, 1000),
      skills: str(b.skills, 300), technologies: str(b.technologies, 300), experience: str(b.experience, 100),
      github: cleanUrl(b.github), portfolio: cleanUrl(b.portfolio), discord: str(b.discord, 100), social_links: str(b.social_links, 500),
      why_join: str(b.why_join, 2000), contribution: str(b.contribution, 2000), project_links: str(b.project_links, 500),
    };
    if (!f.full_name || !f.username || !f.skills || !f.technologies || !f.why_join)
      throw new HttpError(400, "Full name, username, skills, technologies and your reason for joining are required");
    if (!/^[a-z0-9_]{3,30}$/.test(f.username)) throw new HttpError(400, "Username must be 3-30 characters: letters, numbers or _");
    const last = await env.DB.prepare("SELECT status,reviewed_at FROM developer_applications WHERE user_id=? ORDER BY created_at DESC LIMIT 1").bind(user.id).first();
    if (last?.status === "Pending") throw new HttpError(409, "You already have a pending application");
    if (last?.status === "Rejected" && last.reviewed_at && Date.now() - last.reviewed_at < REAPPLY_COOLDOWN_MS) {
      const when = new Date(last.reviewed_at + REAPPLY_COOLDOWN_MS).toISOString().slice(0, 10);
      throw new HttpError(429, `You can reapply after ${when}`);
    }
    const clash = await env.DB.prepare("SELECT id FROM users WHERE username=? AND id<>?").bind(f.username, user.id).first();
    if (clash) throw new HttpError(409, "That username belongs to someone else");
    const id = uid();
    await env.DB.prepare(
      "INSERT INTO developer_applications(id,user_id,full_name,username,location,bio,skills,technologies,experience,github,portfolio,discord,social_links,why_join,contribution,project_links,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    ).bind(id, user.id, f.full_name, f.username, f.location, f.bio, f.skills, f.technologies, f.experience, f.github, f.portfolio, f.discord, f.social_links, f.why_join, f.contribution, f.project_links, "Pending", Date.now()).run();
    return json({ ok: true, id });
  }

  /* --- admin --- */
  if (p === "/api/admin/applications" && m === "GET") {
    if (!isAdmin(user)) throw new HttpError(403, "Forbidden");
    const status = url.searchParams.get("status");
    const where = ["Pending", "Approved", "Rejected"].includes(status) ? "WHERE a.status=?" : "";
    const stmt = env.DB.prepare(`SELECT a.*,u.email AS account_email FROM developer_applications a JOIN users u ON u.id=a.user_id ${where} ORDER BY a.created_at DESC LIMIT 200`);
    const rows = await (where ? stmt.bind(status) : stmt).all();
    return json({ applications: rows.results });
  }

  if ((r = p.match(/^\/api\/admin\/applications\/([^/]+)\/(approve|reject)$/)) && m === "POST") {
    if (!isAdmin(user)) throw new HttpError(403, "Forbidden");
    const [, appId, action] = r;
    const a = await env.DB.prepare("SELECT * FROM developer_applications WHERE id=?").bind(appId).first();
    if (!a) throw new HttpError(404, "Application not found");
    if (a.status !== "Pending") throw new HttpError(409, `Application is already ${a.status}`);
    const now = Date.now();
    if (action === "reject") {
      const reason = str((await body(req)).reason, 500);
      if (!reason) throw new HttpError(400, "A rejection reason is required");
      await env.DB.batch([
        env.DB.prepare("UPDATE developer_applications SET status='Rejected',rejection_reason=?,reviewed_by=?,reviewed_at=? WHERE id=?").bind(reason, user.id, now, appId),
        env.DB.prepare("INSERT INTO notifications(id,user_id,type,title,message,created_at) VALUES(?,?,?,?,?,?)").bind(uid(), a.user_id, "application", "Application rejected", `Reason: ${reason}. You can reapply after 7 days.`, now),
        env.DB.prepare("INSERT INTO admin_actions(id,admin_id,action,target_type,target_id,metadata,created_at) VALUES(?,?,?,?,?,?,?)").bind(uid(), user.id, "reject_application", "application", appId, JSON.stringify({ reason }), now),
      ]);
      return json({ ok: true });
    }
    const taken = await env.DB.prepare("SELECT id FROM users WHERE username=? AND id<>?").bind(a.username, a.user_id).first();
    if (taken) throw new HttpError(409, "That username is now used by another account — reject and ask them to reapply");
    await env.DB.batch([
      env.DB.prepare("UPDATE developer_applications SET status='Approved',reviewed_by=?,reviewed_at=? WHERE id=?").bind(user.id, now, appId),
      env.DB.prepare("UPDATE users SET role=CASE WHEN role='User' THEN 'Developer' ELSE role END, username=? WHERE id=?").bind(a.username, a.user_id),
      env.DB.prepare(
        "INSERT INTO developer_profiles(id,user_id,full_name,location,bio,skills,technologies,experience,github,portfolio,discord,social_links,approved_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET full_name=excluded.full_name,location=excluded.location,bio=excluded.bio,skills=excluded.skills,technologies=excluded.technologies,experience=excluded.experience,github=excluded.github,portfolio=excluded.portfolio,discord=excluded.discord,social_links=excluded.social_links,approved_at=excluded.approved_at"
      ).bind(uid(), a.user_id, a.full_name, a.location, a.bio, a.skills, a.technologies, a.experience, a.github, a.portfolio, a.discord, a.social_links, now),
      env.DB.prepare("INSERT INTO notifications(id,user_id,type,title,message,created_at) VALUES(?,?,?,?,?,?)").bind(uid(), a.user_id, "application", "Application approved", "Welcome! Your developer profile is now public.", now),
      env.DB.prepare("INSERT INTO admin_actions(id,admin_id,action,target_type,target_id,metadata,created_at) VALUES(?,?,?,?,?,?,?)").bind(uid(), user.id, "approve_application", "application", appId, null, now),
    ]);
    return json({ ok: true });
  }

  const tm = p.match(/^\/api\/admin\/team(?:\/([^/]+))?$/);
  if (tm) {
    if (!isAdmin(user)) throw new HttpError(403, "Forbidden");
    const tid = tm[1];
    const log = (action, target) => env.DB.prepare("INSERT INTO admin_actions(id,admin_id,action,target_type,target_id,metadata,created_at) VALUES(?,?,?,?,?,?,?)").bind(uid(), user.id, action, "team", target, null, Date.now()).run();
    if (m === "DELETE" && tid) {
      await env.DB.prepare("DELETE FROM team_members WHERE id=?").bind(tid).run();
      await log("delete_team_member", tid);
      return json({ ok: true });
    }
    if ((m === "POST" && !tid) || (m === "PUT" && tid)) {
      const b = await body(req);
      const f = {
        name: str(b.name, 60), username: str(b.username, 40).toLowerCase(), title: str(b.title, 60), roles: str(b.roles, 200),
        bio: str(b.bio, 500), github: cleanUrl(b.github), discord: str(b.discord, 100), sort: Number.parseInt(b.sort_order, 10),
      };
      if (!Number.isFinite(f.sort)) f.sort = 100;
      if (!f.name || !/^[a-z0-9_.-]{2,40}$/.test(f.username)) throw new HttpError(400, "Name and a username (letters, numbers, _ . -) are required");
      const clash = await env.DB.prepare("SELECT id FROM team_members WHERE username=? AND id<>?").bind(f.username, tid || "").first();
      if (clash) throw new HttpError(409, "That username is already on the team");
      if (tid) {
        if (!(await env.DB.prepare("SELECT id FROM team_members WHERE id=?").bind(tid).first())) throw new HttpError(404, "Team member not found");
        await env.DB.prepare("UPDATE team_members SET username=?,name=?,title=?,roles=?,bio=?,github=?,discord=?,sort_order=? WHERE id=?")
          .bind(f.username, f.name, f.title, f.roles, f.bio, f.github, f.discord, f.sort, tid).run();
        await log("update_team_member", tid);
        return json({ ok: true });
      }
      const id = uid();
      await env.DB.prepare("INSERT INTO team_members(id,username,name,title,roles,bio,github,discord,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)")
        .bind(id, f.username, f.name, f.title, f.roles, f.bio, f.github, f.discord, f.sort, Date.now()).run();
      await log("add_team_member", id);
      return json({ ok: true, id });
    }
  }

  throw new HttpError(404, "Not found");
}

export default {
  async fetch(req, env) {
    const { pathname } = new URL(req.url);
    if (!pathname.startsWith("/api/")) {
      return env.ASSETS ? env.ASSETS.fetch(req) : new Response("Not found", { status: 404 });
    }
    try {
      return await route(req, env);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error(e);
      return json({ error: "Internal server error" }, 500);
    }
  },
};
